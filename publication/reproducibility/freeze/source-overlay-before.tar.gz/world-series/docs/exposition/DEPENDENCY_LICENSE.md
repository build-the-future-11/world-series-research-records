# Dependency / license inventory

| Dependency | Role | Notes |
|---|---|---|
| Python 3.12 | runtime | selected over host 3.14 |
| NumPy | arrays | BSD |
| SciPy | optional numerics | BSD |
| PyTorch | autograd / meta-learning | BSD-style |
| PyYAML | configs | MIT |
| pytest / hypothesis / ruff | dev | BSD/MIT |

Project license field in `pyproject.toml`: Apache-2.0 (placeholder for this workbench; confirm before distribution).
No paid APIs. No cloud schedulers.
