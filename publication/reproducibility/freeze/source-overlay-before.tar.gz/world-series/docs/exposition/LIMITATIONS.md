# Current limitations and retained failures

- The nine modules are bounded implementations, not complete versions of every architecture in the blueprint. The sibling named directories remain empty.
- The current eight-seed studies are development evidence. Repeated seeds share datasets or finite task distributions. No external evaluator, privately frozen protocol, independent replication or confirmatory power analysis is complete.
- Natural-data work covers binary UCI digit tasks, one small neural architecture, short adaptation and limited meta-training. Primary selection hit grid edges; a separately declared sensitivity study checks wider grids and more training.
- The official pretrained Celo2 implementation is now evaluated with pinned source/weights and compatibility checks. Its prior training compute is not matched and source-data overlap is not ruled out. ELO/PETS/DreamCoder remain untested.
- The original Q-APEN model writes memory without reading it. The new causal context-memory intervention has explicit tradeoffs and is not the full expert lifecycle architecture. Prediction-call counts do not equalize compute.
- QWIPII does not show quotient savings in the tested fixed-goal domain. WCODE encoders are untrained structural heuristics, not learned relational models.
- WFIM finite identities are not evidence of novel algebra or downstream benefit. Top-k can violate associativity; the actual coefficient witness is retained.
- WFT learns within each weighted path graph; refitting at a larger size is not transfer. The true-graph oracle is explicitly labeled.
- WPINN uses noisy-only weak assembly, not clean finite-difference targets in the candidate. Quadrature and sparse identification remain limited. Full polynomial rollout exposed 17 failed integrations; affected means are absent rather than survivor-only. This does not establish general PDE discovery.
- CWLNN uses fixed sparse features and trained linear readouts on path graphs. The four-hop target uses residual neighbor aggregation, not a normalized stochastic diffusion operator. No universal-backbone claim is warranted.
- The new Ultron evaluation verifies actual finite-DSL outputs but is local and public. Legacy adapters still use PLUMBING_ONLY verification. No sealed external verifier or general research-agent capability has been demonstrated.
- Wall times reflect implementation overhead and host contention. Methods were not randomized across machine-load conditions; equal step counts do not imply equal wall time, memory or meta-training cost.
- Git baseline and development commits now exist. Earlier manifests with null git_head remain preserved. Source hashes identify exact executed Python source.
- No remote CI, deployment, paper submission or public upload was performed.
