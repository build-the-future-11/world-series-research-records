# Exact next-work queue

1. **QL-02 / QL-03** — matched AdamW/momentum runners + longer-horizon held-out families; finite-diff already smoke-checked.
2. **QW-02 / QW-03** — ranking-only vs verified pruning ablations; expand finite domain sizes; grammar discovery with mandatory false transforms.
3. **WC-02 / WC-03** — shared enumerator pools + hierarchical relational ranker vs token/flat baselines at equal verifier budget.
4. **WP-02 / WP-03** — true weak-form-only assembly (no clean FD leakage) + wrong-conservation ablation logged as failure control.
5. **UL-04** — matched-capability routing study after QW-06/WC-06/WP-06 evidence audits (still blocked for confirmation-style claims).
6. Freeze nothing as confirmation until external evaluator + protocol fields are complete.
