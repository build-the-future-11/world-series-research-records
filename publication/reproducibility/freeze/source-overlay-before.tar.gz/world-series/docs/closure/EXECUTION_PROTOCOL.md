# Closure execution protocol — 24 September 2026

Status: DRAFT_NOT_AUTHORIZED for confirmation. This protocol governs the first cheap decision gates in the approved publication checklist. Prior protocols, results and thresholds remain unchanged. All exposed cases are development data. Scientific classification is distinct from command success.

Baseline source: Git 83b838a47234517733da673113bf59073d24ac27, Python content hash 037b1c7f5ed8781c6622c07c21606b1ae84e90113fd905eeed44eae465038f16. New scripts and exact configuration are hashed into each execution receipt before results are inspected. One CPU worker; no accelerator or paid compute. Initial diagnostic wall cap: 1,800 seconds. Failure/interruption gets its own receipt and never overwrites earlier results.

## Decision gates, declared before these new computations

1. **WFIM:** current per-letter transport is already proved an automorphism. Record the proof and determine whether the existing implementation has any other trainable encode/decode path. Do not launch parameter search for an invariant product.
2. **QWIPII:** enumerate unique states for distinct goals at n=3,4,5,6 and alternating repeated-label goals at n=4,6, an explicit instantiation of the existing finite ring domain. Compute exact goal stabilizers and quotient orbit counts. Exhaustive path/cost correctness at n<=5 and repeated n=6; sample every tenth sorted state at distinct n=6 for bounded search replay. These added repeated-label cases are development feasibility checks, not replacements for the fixed-goal result or a learned-discovery evaluation. Stop efficacy promotion if no useful symmetry exists or any path/shortest-length mismatch appears.
3. **Ultron:** add the missing best-fixed-tool control. Select it using training completion, then training candidate cost, then fixed tool order; never use held success to select it. Evaluate every held family and all 8/24/53 caps. Reproduce original learned results. Bootstrap nine semantic families after averaging repeated example seeds for descriptive 95% intervals (10,000 replicates, seed 240924). No independent-population significance claim. Learned-versus-best-fixed is exploratory, not a newly preregistered primary.
4. **CWLNN:** compare fixed features to receptive-field-matched four-step flat propagation with the same public graph-mean feature available to every readout. Train 12 graphs at n24; evaluate 8 graphs at each n24/48/96, original eight seed units. Compare flat2, flat4, hierarchy, and hierarchy routes 0/4/half/all. Record total feature time and ridge readout error. This diagnoses current prototype attribution, not a replacement for trained-backbone or topology-transfer requirements. Inspect whether routing actually avoids coarse computation.
5. **WPINN:** reconstruct all 288 original fits and identify the 17 failed rollout rows. Record weak design singular values/condition number, coefficients, noise/law and failure status. Do not change solver settings or discard failures. Diagnostics are exploratory; no causal attribution from correlation alone.
6. **QLearn:** complete the missing two corners of the already-exposed 2x2 sensitivity matrix: narrow grid/12 outer steps and wide grid/4 outer steps, each over all eight original seeds and nine methods. Retain original narrow/4 and wide/12 results. Report all 32-step required-cell means, failures, tuning costs and seed-paired factorial differences where complete. This isolates the previously confounded interventions; it does not constitute a fresh natural-data holdout or a full cost-normalized generalization study.

## Shared rules

- Validate expected method/seed/family/condition denominators and identities, not just nonempty outputs. Missing required rows fail the gate.
- Keep training, selection and evaluation labels separate. Preserve failed attempts and missing aggregates.
- Do not select a favorable metric, cap, margin or method after seeing these diagnostics.
- No practical effect margin is fabricated for confirmation. The final meaningful margin, power, target population and externally frozen protocol remain separate unresolved scientific requirements, rather than being replaced with these diagnostics.
- Any apparent gain requires the remaining checklist's stronger controls, robustness, novelty and external requirements before publication readiness.
- Authorship, affiliations, license and venue are pending user input. No signature, reviewer identity, venue acceptance or public submission is generated on their behalf.

Later implementation/study stages require their own versioned contracts after these gates determine whether they are scientifically justified. Running a cheap falsifier does not automatically check the full project block.
