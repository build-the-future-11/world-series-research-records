# Current finite closure

Authoritative closure: `../../../RESEARCH_CLOSURE/FINAL_REPORT.md` and `../../../RESEARCH_CLOSURE/REGISTRY.json`. The entries below are historical progress notes and do not override the closure registry.

The 80-model WFIM selection replay is complete and exact. The isolated historical-source CWLNN replay now exactly reproduces all predictions, permutations and checkpoint selections, plus a full training run. Current tests: 114 passed. Original campaign/run artifacts remain unchanged. Nine original research identities remain explicitly blocked on their protocol/external requirements; scoped negatives are retained.

# Active completion work

The user's goal remains active: execute remaining project work until all
applicable requirements are completed or a real dependency is identified.
Do not equate this progress checkpoint with project or publication completion.
The full 145-item checklist is tracked in CHECKLIST_STATUS.json and the collection
publication master checklist. Three additional items are verified complete:
QL02, WF01 and UL01. Other newly implemented mechanisms have scoped evidence,
but broad paper-level requirements remain open.

## Completed in this continuation

- Recovered the interrupted closure task without overwriting its raw attempts.
  Six narrow/12 cells resumed by verified hashes, two finished in fresh runs;
  all eight wide/4 cells ran. All four factorial corners now contain eight seeds.
- Verified previous QWIPII, Ultron, CWLNN and WPINN gate receipts and documented
  attribution limitations in GATE_RESULTS.md. Preserved the abandoned RUNNING
  manifest with an explicit recovery annotation in RECOVERY.json.
- Recorded the exact WFIM per-letter product-cancellation proof and withdrew
  that implemented product-expressivity claim. The broader coordinate-aware
  proposal is not silently declared completed or discarded.
- Added qapen/causal.py with frozen learned quantization, continuous residuals,
  stable UUID ModuleDict experts and optimizer states, prospective warmup,
  cooldowns, sleep/revival, PRUNED failed candidates, bounded replay/memory,
  delayed counterfactual utility and exact serialized checkpoint restoration.
- Completed 512 stream-method cells and audited all 163,840 predictions.
  Separately reloaded every locally generated checkpoint and verified 1,024
  exact continuation predictions and module/optimizer references.
- QAPEN candidate mean NLL 0.61727, single-memory 0.61225, rolling ridge 0.55893.
  Mechanisms activate but no benefit over the strongest simple control is shown.
  Finite linear-Gaussian scope and cost-proxy limitations remain explicit.

## Immediate continuation

WCODE's trained stage is now executed in numerical commit 58e19d1: 331 canonical
finite functions, six 15,336-parameter scorers, two fixed baselines, eight seeds,
28,416 audited searches and 144 recomputed checkpoint-selection scores. The
runtime type/resource defects are repaired; all 76 tests pass. Relational cap24
completion is 10.54% on family holdouts versus token 9.80%, and 0% on held
compositions. No robust gain over trained controls is established. Fifteen
functions overlap older WCODE/Ultron data (four current evaluation families),
and the overlap is explicitly retained/disclosed. One 80-step training replay
matches loss history and all three checkpoints exactly. No extension is justified
by final-checkpoint selection: all relational seeds select earlier steps.

1. Complete WPINN structured weak-fit failure analysis and learned/conditional
   CWLNN routing. Each needs
   its own source-frozen protocol and matched controls; do not reuse a changed
   source under an old campaign identity.
2. Reconcile stale PAPER_AUDIT/architecture/queue documents with the new evidence,
   build a complete proposal-to-implementation map and claim index, and fix
   package dependence on absolute .portfolio paths. Reproduce from clean
   extracted artifacts before a release claim.
3. Complete substantive original-paper novelty review for retained contributions
   and prepare the remaining manuscript/reproducibility work. External
   confirmation, authorship/licensing and venue decisions cannot be fabricated.

One numerical worker. All current numerical jobs have finished. Preserve all
old campaigns and source snapshots. Current numerical candidate is 3d54b11;
later changes at this checkpoint are analyses/documentation only. Source hash
in each campaign, rather than the latest Git head, identifies its implementation.
The earlier verified delivery stays immutable; build a new delivery for new work.

## WFT stage completed; next executable target is WPINN

The WFT study above is now executed in 3d54b11: verified equitable two-node
coarsening, reflection and invalid-shift controls, independent fine/coarse
fields (11 parameters), 160 learned fits, 64 fixed/oracle controls and 2,688
frozen-transfer rows. Both constraints yield mean error 0.00030388 versus
unconstrained 0.00092856 within the declared finite generator. All primary
predictions agree with NumPy/SciPy to 2.7e-15. Eight compression comparisons
at nearly repeated boundaries need the documented gap-sensitive numerical
verification tolerance; raw ranks and outcomes are unchanged. All 82 tests pass.
Post-study randomized timing covers domain/incidence construction and all other
kernel phases for every case with warmup and three retained repeats. No broad
graph-distribution, equal-wall-time or novelty claim is made.

Next implement WPINN's observed-only neural field/smoother, analytic compact
weak-test quadrature, sparse and physical-structure fits, qualified derivative
and weak baselines, and a frozen noisy/missing/low-excitation trajectory study.
Preserve all 17 original failures and their exact fits. The original proposal's
first retained claim concerns oscillators; PDE discovery is explicitly deferred
and must not be inferred from this stage. Use original-paper/official-source
qualification for SINDy/WSINDy before describing a comparator as a reproduction.
Also finish diagnosis of conditioning, support, quadrature and integration
separately; a correlation table alone cannot establish causes of old failures.

## WPINN development stage completed; next target is CWLNN

Candidate de5df5e completes 120 cells, twelve methods, 240 learned observation
fields, 600 disjoint trajectories and 1,440 selected model evaluations. The
audit exactly replays 6,720 rollouts and every threshold choice, reloads all
240 fields, verifies 720 files, and reproduces one full 400-step training trace.
The original 17 failures persist across three integrators; removing fitted
quadratic terms allows 16 to integrate, while quadrature/test-derivative changes
rescue none of ten weak failures. These are bounded retrospective interventions,
not exclusive conditioning/support causal attribution.

Most new primary aggregates remain incomplete: unconstrained neural weak has
21 failed cells; passive has three. All four passive held failures complete
under Radau/BDF with decreasing energy but substantial prediction error; retain
the original RK45 work-cap failures. No complete performance advantage is shown.
WP05/WP08 complete within the finite oscillator scope. Checklist now 23 complete,
122 open. WPINN's broader identification, joint-physics architecture decision,
held-law, PDE and novelty requirements remain explicit/open.

Next implement genuinely conditional learned CWLNN routing with matched trained
controls, public structural hierarchy, full routing/setup costs, permutation and
batch-boundary tests, held sizes/topologies and a nonhierarchical task. Current
code masks already-computed coarse features and cannot claim compute savings.
All WPINN numerical jobs and audits are finished. Do not overwrite earlier
campaigns or delivery. Follow with collection-wide claim reconciliation, complete
portable packaging, substantive original-paper novelty work and manuscript work.

## CWLNN conditional stage completed

Numerical candidate 6d81c14 implements pre-refinement top-k selection, trained
local/coarse/refinement networks and a learned router with an explicitly declared
selected-node surrogate. Study: 128 models, 23,040 held predictions, all four
budget curves, 115,200 timing repeats, 1,792 disjoint graph IDs. All predictions,
256 checkpoint scores and 23,040 consistent permutations were audited; maximum
permutation discrepancy 4.45e-16. One full 160-update training replay is exact.
All 95 tests pass. Largest operator output in the 100,000-node allocation probe
is N×48; 1% routing executes exactly 1% expensive refinement rows.

Learned half-routing is slower and less accurate than full hierarchy on both
tasks: multiscale MSE 0.011939 vs 0.011412, diffusion 0.032721 vs 0.029831.
Full hierarchy benefits the deliberately aligned task; flat5 wins on diffusion.
The learned-routing advantage is NOT_SUPPORTED within this finite CPU study.
CW01/CW03-CW07 complete within this scope; CW02's arbitrary-tree receptive-field
matching remains open. Checklist: 29 complete, 116 open. Broader novelty,
independent replication and publication requirements are still separate.

All numerical processes are finished. Next reconcile the entire remaining
116-item checklist against original proposals and new evidence, with a concrete
requirement-to-artifact map and executable remaining queue. Do not treat the
scoped studies as full proposal completion: WPINN held-law/joint-physics scope,
WFIM's broader coordinate-aware proposal, comparator qualification and CWLNN
tree matching still need explicit decisions or work. Complete original-paper
novelty review, reproducibility/manuscript artifacts and clean portable delivery
after identifying those gaps. Preserve the earlier verified delivery unchanged.

## Checklist and packaging reconciliation

All 145 requirements are retained in results/requirement_map.json. Original
proposals are preserved under provenance/original-proposals/. The complete
mechanism map identifies actual implementations, discriminating evidence and
remaining original-scope gaps. README and PAPER_AUDIT are reconciled; old versions
are preserved. G01/G02 resolved. WP03 is resolved by the executed sequential
neural-field/physical-structure pipeline: the original proposal makes alternation
optional. WP07 is an explicit N/A because that original first study defers PDEs.
Do not keep calling joint training a required first-study blocker. Held physical
parameter regimes and inverse-PINN/data-only baselines remain real WPINN gaps.

Current checklist: 33 resolved (including one N/A), 112 open: 95 local executable,
six external-required, eleven mixed. This is not a readiness pass. The next
scientific priority is QWIPII verifier domain completeness/trained discovery,
followed by the original WFIM coordinate experiment, heterogeneous Ultron,
QLearn full-family/full-cost work, and remaining project-specific gaps.

The portable builder now includes all campaigns/runs, preserving failures, and
uses locally preserved/hash-checked provenance instead of external .portfolio
inputs. Standalone verification and safe extraction have three regression tests;
the full suite passes 98 tests. A fresh complete review archive and extracted
environment verification are being produced; their actual receipts follow.
