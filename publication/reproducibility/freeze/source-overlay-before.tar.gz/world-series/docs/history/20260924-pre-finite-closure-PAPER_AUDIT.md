# World Series evidence and paper audit

Updated after the CWLNN study (c893c19). The previous audit is preserved in
`docs/history/20260924-pre-reconciliation-PAPER_AUDIT.md`.

A shared working manuscript exists at
`docs/execution/development-v2/RESEARCH_DRAFT.md`. It is a development report,
not nine completed papers or a submission-ready contribution. No independent
confirmation has occurred. All protocols remain DRAFT_NOT_AUTHORIZED.

| Project | Current executed evidence | Scientific limit / next required work |
|---|---|---|
| QLearn | Natural digits, tuned fixed controls, official Celo2, exact training replay and complete 2x2 sensitivity | Strong controls remain better; held optimizee families and full-cost/stability decision incomplete |
| Q-APEN | 512 causal lifecycle/memory cells, 163,840 predictions and exact checkpoint continuation | Mechanisms activate; strongest simple controls remain better; full-cost and original coverage audit required |
| QWIPII | Exact small-domain paths, projective checks and repeated-label feasibility | Fixed-goal no-savings retained; trained discovery and complete-domain certification incomplete |
| WCODE | 331 canonical functions, six trained matched scorers, 28,416 audited searches | No robust trained-control gain; broader DSL coverage, full costs and Ultron overlap decision incomplete |
| WFIM | Classical algebra tests and exact per-letter transport cancellation | Product-expressivity claim withdrawn; originally proposed coordinate-aware learning experiment remains open |
| WFT | Verified symmetry/resolution constraints, 2,688 numerical checks and timing supplement | Bounded transition improvement within equitable graphs; broader distribution/cost/novelty conclusions incomplete |
| WPINN | Observed-only fields, valid passive constraints, official PySINDy controls, 6,720 replayed rollouts | Most aggregate primary means incomplete; required held parameters and inverse-PINN/data-only controls missing |
| CWLNN | 128 trained models, 23,040 audited predictions/permutations, full budget curves | Learned half-routing slower and less accurate; arbitrary-tree receptive-field matching incomplete |
| Ultron | Finite DSL routing and correct nine-family reanalysis | Heterogeneous held capabilities, full costs, evidence attribution and independent verifier absent |

Detailed mechanism mapping: `docs/closure/PROPOSAL_IMPLEMENTATION_MAP.md`.
Current numerical reports and source identities: `docs/closure/*_RESULTS.json`,
original development reports, and `experiments/registry.json`. The registry
retains original studies rather than silently replacing their failures.

No result establishes quantum advantage, ASI, P=NP, unrestricted coding,
Olympiad reasoning, infinite computation, universal transforms or superiority
to unrelated named systems. Celo2 and PySINDy are now qualified package
comparators within stated tasks; ELO and other relevant strong-baseline work
is not thereby complete. No claim of independent replication follows from
same-host replay. Dataset/pretraining and WCODE/Ultron overlap remain disclosed.

The first WPINN proposal explicitly permits sequential observation fitting and
makes alternation optional; later PDEs are deferred. Missing joint optimization
is therefore not a required first-study blocker. Missing held physical parameter
regimes and specified baseline types are real remaining work.

The implementation passes 95 numerical/module tests at the CWLNN candidate.
Packaging tests added later are recorded separately. Clean extracted full
reproduction, complete per-headline provenance, novelty, authorship/license,
review and venue decisions remain unfinished. A local tarball is not a
publication-readiness certificate.
