# Requested work mapped to evidence

This maps the five requested next steps to concrete work. It does not equate a
completed bounded experiment with completion of the full World Series program.

| Requested step | Executed work | Evidence | Remaining boundary |
|---|---|---|---|
| Reconcile status and freeze source | Initial Git snapshot, separate numerical candidate, archived old reports, generated current status/cards/claims | Commits ae046d1 and 429c788; CURRENT_STATUS.md; docs/history/ | Later analysis/docs are separately committed; old raw provenance is preserved |
| Resolve QLearn architecture/cost question | Natural digit matrix, fixed controls, official pretrained Celo2, initialization-only control, identical-parameter state-reset ablation, discrete actions and rollback; separate selection-boundary sensitivity | digits_cells.csv; digits_comparisons.csv; CELO2_PROVENANCE.json; malis_per_seed.csv; sensitivity report | A bounded development answer, not proof about full MALIS or universal optimizer efficiency; timings are not a controlled equal-wall-time comparison |
| Repair weak evaluations | Concrete-coordinate quotient paths; no free semantic pool scoring; actual WFIM counterexample; matched WFT targets; actual causal memory intervention; discriminating solver routing; full-polynomial bounded rollouts | Source/tests in numerical candidate; AUDIT_RECEIPT.json; all_module_cells.csv | Legacy adapters and complete proposed architectures remain narrower than the blueprint |
| Complete development evidence | Eight-seed coverage across nine modules, 178 non-QLearn method/condition cells, raw denominators and failures, broader noise/size/budget conditions, attributed natural data, hash-verified resume and replay | analysis.json; PROTOCOL.md; campaign manifests and receipts | Finite public domains and shared datasets; external full-scale and cross-dataset studies remain open |
| Pursue confirmation and a paper | Working manuscript, reproducible figures/tables, local review bundle and concrete external-evaluation protocol handoff | RESEARCH_DRAFT.md; natural-digits-comparison.pdf; INDEPENDENT_EVALUATION_HANDOFF.md | BLOCKED on independent evaluator/private protocol; no external submission or public upload performed |

The full original meta-training replay is recorded separately under
campaigns/meta-training-replay-v1. Its completion and exactness must be read from
summary.json, not inferred from the presence of a script. The source-visible
development environment cannot certify its own work as independently evaluated.
