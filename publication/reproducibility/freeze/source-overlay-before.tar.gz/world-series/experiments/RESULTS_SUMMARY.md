# RESULTS_SUMMARY (real multiseed artifacts only)

Development multiseed only; DRAFT_NOT_AUTHORIZED; not confirmation.

| Project | n | primary mean | std | outcomes |
|---|---:|---:|---:|---|
| `qapen` | 3 | 1.4702855637294778 | 0.04518569061872792 | INCONCLUSIVE |
| `qlearn` | 3 | 1.5238664644285114 | 2.6394602018323527 | INCONCLUSIVE |
| `qwipii` | 3 | 0.75 | 0.0 | INCONCLUSIVE |
| `ultron` | 3 | 1.0 | 0.0 | INCONCLUSIVE |
| `wpinn` | 3 | 0.16669343047305032 | 0.24935011619360806 | INCONCLUSIVE |

## Raw run IDs

```json
{
  "note": "Development multiseed only; DRAFT_NOT_AUTHORIZED; not confirmation.",
  "projects": {
    "qapen": {
      "runs": [
        {
          "run_id": "20260922T220229_34d8ed9d",
          "seed": 2,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220226_6044f91c",
          "seed": 0,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220228_88d22774",
          "seed": 1,
          "status": "SUCCEEDED"
        }
      ],
      "primary_aggregate": {
        "mean": 1.4702855637294778,
        "std": 0.04518569061872792,
        "n": 3
      },
      "research_outcomes": [
        "INCONCLUSIVE"
      ]
    },
    "qlearn": {
      "runs": [
        {
          "run_id": "20260922T220223_c80378c6",
          "seed": 2,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220216_a554949f",
          "seed": 0,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220220_9b72c7cd",
          "seed": 1,
          "status": "SUCCEEDED"
        }
      ],
      "primary_aggregate": {
        "mean": 1.5238664644285114,
        "std": 2.6394602018323527,
        "n": 3
      },
      "research_outcomes": [
        "INCONCLUSIVE"
      ]
    },
    "qwipii": {
      "runs": [
        {
          "run_id": "20260922T220231_61f019e7",
          "seed": 0,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220234_6769c529",
          "seed": 2,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220233_5b6e56fb",
          "seed": 1,
          "status": "SUCCEEDED"
        }
      ],
      "primary_aggregate": {
        "mean": 0.75,
        "std": 0.0,
        "n": 3
      },
      "research_outcomes": [
        "INCONCLUSIVE"
      ]
    },
    "ultron": {
      "runs": [
        {
          "run_id": "20260922T220243_3506d0ca",
          "seed": 1,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220241_2fef4d22",
          "seed": 0,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220244_60244691",
          "seed": 2,
          "status": "SUCCEEDED"
        }
      ],
      "primary_aggregate": {
        "mean": 1.0,
        "std": 0.0,
        "n": 3
      },
      "research_outcomes": [
        "INCONCLUSIVE"
      ]
    },
    "wpinn": {
      "runs": [
        {
          "run_id": "20260922T220239_e701df07",
          "seed": 2,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220236_40092f09",
          "seed": 0,
          "status": "SUCCEEDED"
        },
        {
          "run_id": "20260922T220238_f045b8a1",
          "seed": 1,
          "status": "SUCCEEDED"
        }
      ],
      "primary_aggregate": {
        "mean": 0.16669343047305032,
        "std": 0.24935011619360806,
        "n": 3
      },
      "research_outcomes": [
        "INCONCLUSIVE"
      ]
    }
  }
}
```
