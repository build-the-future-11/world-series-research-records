"""World-FIM infinity — sparse word algebra."""
