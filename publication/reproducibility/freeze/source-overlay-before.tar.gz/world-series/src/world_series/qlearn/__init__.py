"""Quantum Learning / MALIS — bounded meta-learned updates."""
