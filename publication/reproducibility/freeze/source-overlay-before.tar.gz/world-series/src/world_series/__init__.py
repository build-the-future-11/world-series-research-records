"""World Series v0.1 — installable research workbench."""

from __future__ import annotations

__version__ = "0.1.0"
__schema_version__ = "0.1.0"

PROJECT_NAMESPACES = (
    "qlearn",
    "qapen",
    "qwipii",
    "wcode",
    "wfim",
    "wft",
    "wpinn",
    "cwlnn",
    "ultron",
)
