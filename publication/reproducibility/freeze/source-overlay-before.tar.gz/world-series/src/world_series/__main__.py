"""python -m world_series"""

from __future__ import annotations

from world_series.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
