"""World-PINN — weak-form oscillator law identification."""
