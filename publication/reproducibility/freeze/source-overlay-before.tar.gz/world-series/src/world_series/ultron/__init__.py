"""Ultron — verified budgeted orchestration."""
