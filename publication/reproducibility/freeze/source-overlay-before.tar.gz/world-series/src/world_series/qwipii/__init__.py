"""QWIPII — verified invariant-guided search."""
