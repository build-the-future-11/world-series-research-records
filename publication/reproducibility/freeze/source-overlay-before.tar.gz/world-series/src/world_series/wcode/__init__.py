"""World-CNN Code — typed bounded DSL synthesis."""
