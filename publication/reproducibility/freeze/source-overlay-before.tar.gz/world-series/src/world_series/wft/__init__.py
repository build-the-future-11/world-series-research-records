"""World Fourier Transform — weighted graph spectral operators."""
