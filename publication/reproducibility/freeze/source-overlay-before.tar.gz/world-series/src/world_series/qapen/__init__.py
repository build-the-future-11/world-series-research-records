"""Q-APEN — finite adaptive probabilistic experts + engrams."""
