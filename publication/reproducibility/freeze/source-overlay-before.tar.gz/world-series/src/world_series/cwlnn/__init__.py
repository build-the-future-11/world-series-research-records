"""CWLNN — sparse multiscale graph hierarchy."""
