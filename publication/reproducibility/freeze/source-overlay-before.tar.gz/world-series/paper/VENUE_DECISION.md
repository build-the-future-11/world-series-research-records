# Working submission target: AISTATS 2027

Verified 2026-09-24 against https://virtual.aistats.org/Conferences/2027/CallForPapers and https://aistats.org/aistats2027/dates.html.

Abstract: September 29, 2026, 23:59 AoE. Full paper and all supplement: October 6, 2026, 23:59 AoE. Main text limit eight pages, excluding references, AI Use Statement, reproducibility checklist and appendices. Review is double blind. Author list freezes at abstract deadline. Reciprocal reviewer nomination or justified exemption is required. Actual author eligibility and profiles remain unverified.

This is a target, not an eligibility or scientific-readiness verdict. The nine-module evidence report is the comprehensive preprint development source; a coherent conference contribution still requires selection and novelty review. Do not force unrelated studies into eight pages or call nine prototypes nine papers.

Neutral preprints are allowed; they must not identify themselves as AISTATS submissions during review. arXiv requires the available TeX sources and dependencies: https://info.arxiv.org/help/submit_tex.html. Author identities, license choice, endorsement/account eligibility, final author review, and scientific release gates remain unresolved. No submission has been made.
