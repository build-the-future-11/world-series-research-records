# Reference audit — 2026-09-24

Primary arXiv metadata and abstracts checked for 1606.04474, 1509.03580, 2005.04339 and 2602.19142; the SINDy PNAS DOI was also checked. Manuscript summaries are limited to the mechanisms described in these primary abstracts. This is bibliographic verification and background attribution, not full-paper novelty review. Remaining module-specific closest-work comparisons stay open. No acceptance, implementation parity or reproduced-paper claim is inferred from a citation.
